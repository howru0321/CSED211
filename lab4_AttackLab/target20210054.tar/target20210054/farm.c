/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

unsigned addval_392(unsigned x)
{
    return x + 3284633928U;
}

unsigned getval_231()
{
    return 3284633928U;
}

unsigned getval_142()
{
    return 3281031288U;
}

unsigned getval_138()
{
    return 3267856712U;
}

void setval_137(unsigned *p)
{
    *p = 2425510098U;
}

void setval_188(unsigned *p)
{
    *p = 2421686938U;
}

unsigned getval_262()
{
    return 2421716352U;
}

void setval_341(unsigned *p)
{
    *p = 2428995848U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

unsigned addval_272(unsigned x)
{
    return x + 3247493513U;
}

void setval_383(unsigned *p)
{
    *p = 3221799565U;
}

unsigned getval_442()
{
    return 3523792521U;
}

unsigned addval_362(unsigned x)
{
    return x + 3380137609U;
}

void setval_244(unsigned *p)
{
    *p = 2463205733U;
}

unsigned getval_226()
{
    return 3677933209U;
}

unsigned getval_406()
{
    return 3680555401U;
}

unsigned getval_372()
{
    return 2447411528U;
}

void setval_356(unsigned *p)
{
    *p = 3221275273U;
}

unsigned getval_468()
{
    return 3252717896U;
}

void setval_109(unsigned *p)
{
    *p = 3353381192U;
}

void setval_258(unsigned *p)
{
    *p = 2428672479U;
}

void setval_388(unsigned *p)
{
    *p = 3281044105U;
}

void setval_384(unsigned *p)
{
    *p = 3286280520U;
}

unsigned addval_127(unsigned x)
{
    return x + 3525362313U;
}

void setval_230(unsigned *p)
{
    *p = 3525365417U;
}

unsigned addval_475(unsigned x)
{
    return x + 1086443913U;
}

unsigned getval_313()
{
    return 3281044097U;
}

unsigned addval_293(unsigned x)
{
    return x + 2447411528U;
}

void setval_194(unsigned *p)
{
    *p = 3687109001U;
}

unsigned addval_236(unsigned x)
{
    return x + 2425541001U;
}

unsigned getval_334()
{
    return 3286272328U;
}

void setval_440(unsigned *p)
{
    *p = 3687108233U;
}

void setval_484(unsigned *p)
{
    *p = 1656999561U;
}

unsigned addval_470(unsigned x)
{
    return x + 3284306021U;
}

unsigned getval_279()
{
    return 2464188744U;
}

void setval_462(unsigned *p)
{
    *p = 3515434713U;
}

unsigned addval_370(unsigned x)
{
    return x + 3674263177U;
}

unsigned addval_232(unsigned x)
{
    return x + 3376988809U;
}

void setval_157(unsigned *p)
{
    *p = 3286272328U;
}

unsigned getval_347()
{
    return 3224424073U;
}

unsigned addval_483(unsigned x)
{
    return x + 3229929865U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
